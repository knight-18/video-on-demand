/*
ENV_VARIABLES
- REGION : AWS REGIOS FOR RESOURCES
- DB_SHORT_VIDEOS_TABLE_NAME : DynamoDB Table name to store short videos data
*/
const AWS = require("aws-sdk");
AWS.config.update({
  region: process.env.REGION || "us-east-1",
});
const db = new AWS.DynamoDB.DocumentClient();
exports.handler = async (event) => {
  let response;
  try {
    console.log("Function execution started...", event);
    let requestBody = JSON.parse(event.body);

    let { id, name, uploadedBy, sourceBucketFilePath, createdAt, isDeleted } =
      requestBody;

    let videoDocData = {
      id: id,
      name: name,
      uploadedBy: uploadedBy,
      sourceBucketFilePath: sourceBucketFilePath,
      createdAt: createdAt,
      isDeleted: isDeleted,
    };

    await db
      .put({
        TableName: process.env.DB_SHORT_VIDEOS_TABLE_NAME,
        Item: videoDocData,
      })
      .promise();
    response = {
      statusCode: 201,
      body: JSON.stringify("Written to dynamoDB:", videoDocData),
    };
  } catch (err) {
    response = {
      statusCode: 500,
      body: JSON.stringify(`Failed to write to dynamoDB:${err}`),
    };
  }

  return response;
};
