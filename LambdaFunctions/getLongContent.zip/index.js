/*
ENV_VARIABLES
- REGION : AWS REGION FOR RESOURCES
- DB_LONG_VIDEOS_TABLE_NAME : DynamoDB Table name to store LONG videos data
- DB_LANGUAGEWISE_VIDEOS_TABLE_NAME : DynamoDB Table name to store videos languauge wise
- DB_GENREWISE_VIDEOS_TABLE_NAME : DynamoDB Table name to store videos genrewise
*/
const AWS = require("aws-sdk");
AWS.config.update({
  region: process.env.REGION || "us-east-1",
});
const db = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
  console.log("Event: ", event);
  const {
    DB_LONG_VIDEOS_TABLE_NAME,
    DB_LANGUAGEWISE_VIDEOS_TABLE_NAME,
    DB_GENREWISE_VIDEOS_TABLE_NAME,
  } = process.env;
  const databaseMap = {
    "Filter By Genre": {
      table: DB_GENREWISE_VIDEOS_TABLE_NAME,
      attribute: "genre",
    },
    "Filter By Language": {
      table: DB_LANGUAGEWISE_VIDEOS_TABLE_NAME,
      attribute: "languageName",
    },
  };
  try {
    let { filterType, filterValue, limit, lastEvaluatedKey } = JSON.parse(
      event.body
    );
    // let {filterType, filterValue, limit} = event

    let params = {
      TableName: databaseMap[filterType].table,
      FilterExpression: `${databaseMap[filterType].attribute} = :value`,
      ExpressionAttributeValues: { ":value": filterValue },
      ScanIndexForward: false,
    };
    if (limit) {
      params.Limit = limit;
    }
    if (lastEvaluatedKey) {
      params.ExclusiveStartKey = lastEvaluatedKey;
    }
    console.log("Params:", params);
    let data = await db.scan(params).promise();
    console.log("Data :", data);
    if (data.Items.length) {
      let batchParams = {
        RequestItems: {
          [DB_LONG_VIDEOS_TABLE_NAME]: {
            Keys: [],
          },
        },
      };
      data.Items.forEach((video) => {
        batchParams.RequestItems[DB_LONG_VIDEOS_TABLE_NAME].Keys.push({
          id: video.videoId,
        });
      });
      console.log("Batch Params :", batchParams);
      let videoData = await db.batchGet(batchParams).promise();
      console.log("videoData: ", videoData);
      if (data.LastEvaluatedKey) {
        videoData.LastEvaluatedKey = data.LastEvaluatedKey;
      }
      return {
        statusCode: 200,
        body: JSON.stringify(videoData),
      };
    } else {
      let videoData = {
        Responses: {
          [DB_LONG_VIDEOS_TABLE_NAME]: [],
        },
      };
      return {
        statusCode: 200,
        body: JSON.stringify(videoData),
      };
    }
  } catch (error) {
    console.log(error);
    return {
      statusCode: 500,
      body: JSON.stringify(error),
    };
  }
};
