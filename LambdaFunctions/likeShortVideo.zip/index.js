/*
ENV_VARIABLES
- REGION : AWS REGIOS FOR RESOURCES
- DB_SHORT_VIDEO_LIKES_TABLE_NAME : DynamoDB Table name to store LONG videos data
*/
const AWS = require("aws-sdk");
AWS.config.update({
  region: process.env.REGION || "us-east-1",
});

const db = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
  const DB_SHORT_VIDEO_LIKES_TABLE_NAME =
    process.env.DB_SHORT_VIDEO_LIKES_TABLE_NAME;
  let reqBody = JSON.parse(event.body);
  let params = {
    TableName: DB_SHORT_VIDEO_LIKES_TABLE_NAME,
    Item: {
      user: reqBody.user,
      videoId: reqBody.videoId,
      createdAt: parseInt(reqBody.createdAt),
      status: true,
    },
  };
  try {
    await db.put(params).promise();
    return {
      statusCode: 200,
      body: JSON.stringify("Successful"),
    };
  } catch (error) {
    console.log(error);
    return {
      statusCode: 500,
      body: JSON.stringify(error),
    };
  }
};
