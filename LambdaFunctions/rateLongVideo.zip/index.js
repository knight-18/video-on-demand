/*
Env Variables
DB_VIDEO_RATING_TABLE_NAME - Dynamo DB table name to store ratings
REGION - AWS Region name for resources
*/
const AWS = require("aws-sdk");
AWS.config.update({
  region: process.env.REGION || "us-east-1",
});

const db = new AWS.DynamoDB.DocumentClient();

const { roundToTwo, updateItemInDynamo } = require("./utils.js");
exports.handler = async (event) => {
  try {
    console.log("EVENT: ", event);
    const DB_VIDEO_RATING_TABLE_NAME = process.env.DB_VIDEO_RATING_TABLE_NAME;

    let { videoId, user, createdAt, rating } = JSON.parse(event.body);
    // let {videoId, user, createdAt, rating} = event
    let params = {
      TableName: DB_VIDEO_RATING_TABLE_NAME,
      Item: {
        videoId: videoId,
        user: user,
        createdAt: createdAt,
        rating: rating,
        isActive: true,
      },
    };
    console.log("Params:", params);
    await db.put(params).promise();

    let queryParams = {
      TableName: process.env.DB_VIDEO_RATING_TABLE_NAME,
      KeyConditions: {
        videoId: {
          ComparisonOperator: "EQ",
          AttributeValueList: [videoId],
        },
      },
    };
    let queryRes = await db.query(queryParams).promise();
    if (queryRes.Items.length) {
      let totalRating = 0;
      queryRes.Items.forEach((rating) => {
        totalRating += rating.rating;
      });
      let averageRating = roundToTwo(totalRating / queryRes.Items.length);
      let docData = {
        averageRating: averageRating,
      };
      await updateItemInDynamo(
        db,
        process.env.DB_LONG_VIDEOS_TABLE_NAME,
        videoId,
        docData
      );
    }

    return {
      statusCode: 200,
      body: JSON.stringify("Successful"),
    };
  } catch (error) {
    console.log("Error: ", error);
    return {
      statusCode: 500,
      body: JSON.stringify(error),
    };
  }
};
