import os
import boto3
import requests
import json
from requests_aws4auth import AWS4Auth

region = 'us-east-1'
service = 'es'

credentials = boto3.Session().get_credentials()
awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, region, service, session_token=credentials.token)
def lambda_handler(event, context):
    event = json.dumps(event)
    data = json.loads(json.loads(str(event))['body'])
    es_host = os.environ['OPENSEARCH_DOMAIN']
    # es_host = 'https://search-test-nphfo7bxp7pxj5onsg5pzqyfom.us-east-1.es.amazonaws.com'
    es_index = data['_index']
    es_type = data['_type']
    url = es_host + '/' + es_index + '/' + es_type + '/'
    id = data['id']
    document = {
        'title' : data['title'],
        'genres' : data['genres'],
        'about' : data['about']
    }
    print(document)
    res = requests.put(url+id, auth = awsauth, json=document, headers={"Content-Type": "application/json"})
    return 'success'
