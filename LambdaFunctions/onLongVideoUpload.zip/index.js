/*
ENV_VARIABLES
- REGION : AWS REGIOS FOR RESOURCES
- DB_LONG_VIDEOS_TABLE_NAME : DynamoDB Table name to store long videos data
- DB_LANGUAGEWISE_VIDEOS_TABLE_NAME : DB Table name to store videos language wise
- DB_GENREWISE_VIDEOS_TABLE_NAME : DB Table name to store videos genrewise
*/
const AWS = require("aws-sdk");
AWS.config.update({
  region: process.env.REGION || "us-east-1",
});
const db = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
  let response;
  const {
    DB_LONG_VIDEOS_TABLE_NAME,
    DB_LANGUAGEWISE_VIDEOS_TABLE_NAME,
    DB_GENREWISE_VIDEOS_TABLE_NAME,
  } = process.env;
  try {
    console.log("Function execution started...");
    console.log("Event: ", event);
    let requestBody = JSON.parse(event.body);

    let {
      id,
      name,
      about,
      uploadedBy,
      sourceBucketFilePath,
      language,
      genres,
      createdAt,
      title,
      isPremium,
    } = requestBody;

    let videoDocData = {
      id: id,
      name: name,
      about: about,
      uploadedBy: uploadedBy,
      sourceBucketFilePath: sourceBucketFilePath,
      language: language,
      genres: genres,
      createdAt: createdAt,
      isDeleted: false,
      title: title,
      isPremium,
    };

    await db
      .put({
        TableName: DB_LONG_VIDEOS_TABLE_NAME,
        Item: videoDocData,
      })
      .promise();

    let languagewiseParams = {
      TableName: DB_LANGUAGEWISE_VIDEOS_TABLE_NAME,
      Item: {
        languageName: language,
        videoId: id,
        createdAt,
      },
    };
    console.log("Languagewise Params: ", languagewiseParams);
    await db.put(languagewiseParams).promise();

    let genrewiseItems = [];
    genres.forEach((genre) => {
      genrewiseItems.push({
        PutRequest: {
          Item: {
            genre: genre,
            videoId: id,
            createdAt,
          },
        },
      });
    });
    let genrewiseParams = {
      RequestItems: {
        [DB_GENREWISE_VIDEOS_TABLE_NAME]: genrewiseItems,
      },
    };
    console.log("Genrewise Params: ", genrewiseParams);
    await db.batchWrite(genrewiseParams).promise();
    response = {
      statusCode: 201,
      body: JSON.stringify("Written to dynamoDB:", videoDocData),
    };
    console.log("Written to DB: ", DB_LONG_VIDEOS_TABLE_NAME);
  } catch (err) {
    console.log("ERROR: ", err);
    response = {
      statusCode: 500,
      body: JSON.stringify(`Failed to write to dynamoDB:${err}`),
    };
  }

  return response;
};
