/*
ENV_VARIABLES
- REGION : AWS REGIOS FOR RESOURCES
- DB_SHORT_VIDEOS_TABLE_NAME : DynamoDB Table name to store short videos data
*/
const AWS = require("aws-sdk");

AWS.config.update({
  region: process.env.REGION || "us-east-1",
});
const db = new AWS.DynamoDB.DocumentClient();
exports.handler = async (event) => {
  console.log("Event Info: ", event);
  let reqBody = JSON.parse(event.body);
  let limit = reqBody.limit;
  let LastEvaluatedKey = reqBody.LastEvaluatedKey;
  let params = LastEvaluatedKey
    ? {
        TableName: process.env.DB_SHORT_VIDEOS_TABLE_NAME,
        IndexName: "id-created-at-index",
        Limit: parseInt(limit),
        ExclusiveStartKey: LastEvaluatedKey,
        ScanIndexForward: false,
      }
    : {
        TableName: process.env.DB_SHORT_VIDEOS_TABLE_NAME,
        IndexName: "id-created-at-index",
        Limit: parseInt(limit),
        ScanIndexForward: false,
      };
  try {
    let data = await db.scan(params).promise();
    console.log("Data: ", data);
    return {
      statusCode: 200,
      body: JSON.stringify(data),
    };
  } catch (err) {
    console.log(err);
    return {
      statusCode: 500,
      body: JSON.stringify(err),
    };
  }
};
