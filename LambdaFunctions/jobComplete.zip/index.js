const utils = require("./lib/utils.js");

exports.handler = async (event) => {
  console.log(`REQUEST:: ${JSON.stringify(event, null, 2)}`);

  const {
    MEDIACONVERT_ENDPOINT,
    CLOUDFRONT_DOMAIN,
    SOURCE_BUCKET,
    JOB_MANIFEST,
    METRICS,
    SOLUTION_ID,
    VERSION,
    UUID,
  } = process.env;

  try {
    const status = event.detail.status;

    switch (status) {
      case "INPUT_INFORMATION":
        /**
         * Write source info to the job manifest
         */
        try {
          await utils.writeManifest(SOURCE_BUCKET, JOB_MANIFEST, event);
        } catch (err) {
          throw err;
        }
        break;
      case "COMPLETE":
        try {
          /**
           * get the mediaconvert job details and parse the event outputs
           */
          console.log("Processing job details");
          const jobDetails = await utils.processJobDetails(
            MEDIACONVERT_ENDPOINT,
            CLOUDFRONT_DOMAIN,
            event
          );
          /**
           * update the master manifest file in s3
           */
          console.log("Processed Job details");
          console.log("Writing manifest");
          const results = await utils.writeManifest(
            SOURCE_BUCKET,
            JOB_MANIFEST,
            jobDetails
          );
          console.log("Done writing manifest");
          /**
           * if enabled send annoymous data to the solution builder api, this helps us with future release
           */
          if (METRICS === "Yes") {
            await utils.sendMetrics(SOLUTION_ID, VERSION, UUID, results);
          }
          /**
           *    Update destination bucket url in db
           */
          let docData = {
            destinationVideoDetails: event.detail.outputGroupDetails[0],
            destinationBucketFilePath:
              event.detail.outputGroupDetails[0].playlistFilePaths,
          };
          console.log("Updating data in db");
          await utils.updateDestinationVideoUrl(
            event.detail.userMetadata.Guid.split("/")[2],
            docData,
            event.detail.userMetadata.Guid.split("/")[1]
          );
          console.log("Updated data in Database");
        } catch (err) {
          throw err;
        }
        break;
      case "CANCELED":
      case "ERROR":
        console.log("Error");
        break;
      default:
        throw new Error("Unknow job status");
    }
  } catch (err) {
    console.log("ERROR: ", err);
    throw err;
  }
  return;
};
