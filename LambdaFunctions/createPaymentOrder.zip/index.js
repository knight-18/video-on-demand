const shortid = require("shortid");
const Razorpay = require("razorpay");

const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID,
  key_secret: process.env.RAZORPAY_KEY_SECRET,
});
const PRICING = {
  1: 99,
  3: 289,
  6: 569,
  12: 899,
};
const CURRENCY = "INR";

exports.handler = async (event) => {
  console.log("EVENT: ", event);
  let requestBody = JSON.parse(event.body);

  const payment_capture = 1;
  const amount = PRICING[requestBody.months.toString()];

  const options = {
    amount: amount * 100,
    currency: CURRENCY,
    receipt: shortid.generate(),
    payment_capture,
  };
  try {
    const response = await razorpay.orders.create(options);
    console.log(response);
    return {
      statusCode: 200,
      body: JSON.stringify({
        id: response.id,
        currency: response.currency,
        amount: response.amount,
      }),
    };
  } catch (error) {
    console.log(error);
    return {
      statusCode: 500,
      body: JSON.stringify(error),
    };
  }
};
