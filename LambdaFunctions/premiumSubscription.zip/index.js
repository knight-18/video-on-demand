const AWS = require("aws-sdk");
AWS.config.update({
  region: process.env.REGION || "us-east-1",
});
const db = new AWS.DynamoDB.DocumentClient();
const MILLISECONDS_IN_A_SECOND = 1000;
const MILLISECONDS_IN_A_MINUTE = 60 * MILLISECONDS_IN_A_SECOND;
const MILLISECONDS_IN_A_HOUR = 60 * MILLISECONDS_IN_A_MINUTE;
const MILLISECONDS_IN_A_DAY = 24 * MILLISECONDS_IN_A_HOUR;
const DAYS_IN_A_MONTH = 30;
exports.handler = async (event) => {
  const { DB_SUBSCRIPTION_TABLE_NAME } = process.env;
  try {
    console.log("Function execution started...");
    console.log("Event: ", event);
    let requestBody = JSON.parse(event.body);

    let { id, months } = requestBody;
    months = parseInt(months);
    let currentTimestamp = Date.now();
    let subscriptionEndTimestamp =
      currentTimestamp + months * DAYS_IN_A_MONTH * MILLISECONDS_IN_A_DAY;
    let docData = {
      userId: id,
      subscriptionStartTimestamp: currentTimestamp,
      subscriptionEndTimestamp,
    };

    await db
      .put({
        TableName: DB_SUBSCRIPTION_TABLE_NAME,
        Item: docData,
      })
      .promise();
    return {
      statusCode: 200,
      body: JSON.stringify("Successful"),
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify(error),
    };
  }
};
