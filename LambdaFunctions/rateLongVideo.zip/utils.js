function roundToTwo(num) {
  return +(Math.round(num + "e+2") + "e-2");
}

const updateItemInDynamo = async (db, tableName, id, documentData) => {
  console.log("Document Data: ", documentData);

  let updateExpression = "set";
  let ExpressionAttributeNames = {};
  let ExpressionAttributeValues = {};
  for (const property in documentData) {
    updateExpression += ` #${property} = :${property} ,`;
    ExpressionAttributeNames["#" + property] = property;
    ExpressionAttributeValues[":" + property] = documentData[property];
  }

  // console.log(ExpressionAttributeNames);

  updateExpression = updateExpression.slice(0, -1);

  const params = {
    TableName: tableName,
    Key: {
      id: id,
    },
    UpdateExpression: updateExpression,
    ExpressionAttributeNames: ExpressionAttributeNames,
    ExpressionAttributeValues: ExpressionAttributeValues,
  };

  console.log("Params : ", params);
  let result = await db.update(params).promise();

  return result;
};

module.exports = { roundToTwo, updateItemInDynamo };
