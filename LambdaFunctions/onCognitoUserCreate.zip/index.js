/*
ENV_VARIABLES
- REGION : AWS REGIOS FOR RESOURCES
- DB_USERS_TABLE_NAME : DynamoDB Table name to store users data
*/
const AWS = require("aws-sdk");
AWS.config.update({
  region: process.env.REGION || "us-east-1",
});
const dynamo = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event, context) => {
  console.log("Function execution started...");
  console.log("Event: ", event);

  const tableName = process.env.DB_USERS_TABLE_NAME;
  const region = process.env.REGION || "us-east-1";

  console.log("table=" + tableName + " -- region=" + region);

  // If the required parameters are present, proceed
  if (event.userName) {
    // -- Write data to DDB
    let ddbParams = {
      Item: {
        id: event.userName,
        email: event.request.userAttributes.email,
        createdAt: Date.now(),
      },
      TableName: tableName,
    };

    // Call DynamoDB
    try {
      await dynamo.put(ddbParams).promise();
      console.log(`User details saved to DB: ${tableName}`, ddbParams);
    } catch (err) {
      console.log(`Error in saving details to DB: ${tableName}`, err);
    }

    console.log("Success: Everything executed correctly");
    context.done(null, event);
  } else {
    // Nothing to do, the user's email ID is unknown
    console.log("Error: Username is not present");
    context.done(null, event);
  }
};
