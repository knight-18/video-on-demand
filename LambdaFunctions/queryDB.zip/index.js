const AWS = require("aws-sdk");
AWS.config.update({
  region: process.env.REGION || "us-east-1",
});

const db = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
  console.log("Request: ", event);
  let reqBody = JSON.parse(event.body);
  // let reqBody = event
  let KeyConditions = new Object();
  reqBody.keyConditions.forEach((condition) => {
    KeyConditions[condition.attributeName] = {
      ComparisonOperator: condition.comparisonOperator,
      AttributeValueList: condition.attributeValueList,
    };
  });

  let queryParams = {
    TableName: reqBody.tableName,
    KeyConditions: KeyConditions,
  };
  if (reqBody.limit) {
    queryParams.Limit = reqBody.limit;
  }
  console.log("QueryParams: ", queryParams);
  try {
    let data = await db.query(queryParams).promise();
    console.log("Data:", data);
    return {
      statusCode: 200,
      body: JSON.stringify(data),
    };
  } catch (error) {
    console.log(error);
    return {
      statusCode: 500,
      body: JSON.stringify(error),
    };
  }
};
